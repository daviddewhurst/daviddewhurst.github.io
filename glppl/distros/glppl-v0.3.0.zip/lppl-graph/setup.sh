cd include
rm -rf lppl
git clone -b 'master' git@gitlab.com:drdewhurst/lppl.git