# `fmcs`

`fmcs` -- the fast monte carlo system -- is a low-resource universal probabilistic programming framework.

## Requirements

Requires `zip.hpp` from [`cppitertools`](https://github.com/ryanhaining/cppitertools) to be in the `include` directory.

## Build
`./setup.sh && cd build && cmake .. && make`. Requires (a) a compiler that supports C++ 20 and (b) CMake v3.20.0 or later. 

**Please note** that `fmcs` has been tested on Apple clang v12.0.0 on OSX, Mingw-w64 on Windows 10, g++ 11.3.0 on pop!_os, and emscripten 4.0.7 on pop!_os. It *should* compile under any standards compliant C++20 compiler, but that is not guaranteed. Please submit build errors here: https://gitlab.com/drdewhurst/fmcs/-/issues.  

## Test
Run any of the tests that show up in the `build` directory after you build. E.g., `./record_test`. **Please note** that deterministic results are guaranteed under specific hardware configurations, but not across operating systems.

## License etc.

`fmcs` is free software released under the terms of the GNU General Public License (GPL) v3. Copyright DXDelta, LLC and David Rushing Dewhurst, 2022 - present.
