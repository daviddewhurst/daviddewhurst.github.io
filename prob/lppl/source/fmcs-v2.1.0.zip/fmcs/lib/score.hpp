/**
 * @file score.hpp
 * @author David Dewhurst (drd@davidrushingdewhurst.com)
 * @brief 
 * @version 0.1
 * @date 2024-03-25
 * 
 * @copyright Copyright (c) 2024
 * 
 */

#include <distribution_traits.hpp>
#include <record.hpp>

#ifndef SCORE_H
#define SCORE_H

struct Score {
    template<typename RNG>
    double sample(RNG& rng) { return 0.0; }
    std::string string() const { return "Score()"; }
};

template<typename... Ts>
void score(record_t<DTypes<Ts...>>& r, std::string address, double value) {
    static_assert(
        type_subset<DTypes<Score>, DTypes<Ts...>>::value, 
        "dist types should include Score"
    );
    auto node = node_t<Score> { 
        .distribution=Score(),
        .value=value,
        .logprob=value,
        .obs=true,
        .interp=NodeCondition(),
        .last_interp=NodeCondition()
    };
    if (!r.map.contains(address)) r.addresses.push_back(address);
    r.map.insert_or_assign(address, node);
}

#endif  // SCORE_H