/**
 * @file test_score.cpp
 * @author David Dewhurst (drd@davidrushingdewhurst.com)
 * @brief 
 * @version 0.1
 * @date 2024-03-26
 * 
 * @copyright Copyright (c) 2024
 * 
 */

#include <random>

#include <distributions.hpp>
#include <record.hpp>
#include <score.hpp>
#include <inference/importance/likelihood.hpp>
#include <query.hpp>

std::minstd_rand rng(2024);

double random_walk_model(record_t<DTypes<Normal, Score>>& r, std::vector<double>& values) {
    auto loc = sample(r, "loc", Normal(), rng);
    auto log_scale = sample(r, "log_scale", Normal(), rng);
    auto init = sample(r, "init", Normal(), rng);
    double val = 0.0, pos = init;
    // use Score to roll your own (efficient) observation plate
    for (const auto& x : values) {
        auto dist = Normal(loc + pos, std::exp(log_scale));
        pos = dist.sample(rng);
        val += dist.logprob(x);
    }
    score(r, "pos", val);
    return loc;
}

int test_score() {

    std::vector<double> values({0.0, 1.0, -0.2, -0.4, -0.5, -1.1, -1.5, -0.84});
    pp_t<std::vector<double>&, double, Normal, Score> f = random_walk_model;
    auto q = ProductGenerator<WeightedMeanStd, std::pair<double, double>, double, Normal, Score>::generate({"loc", "log_scale"});
    auto opts = inf_options_t(1000);
    auto infer = inference<LikelihoodWeighting>(f, q, opts);
    auto res = infer(std::ref(values));
    for (const auto& [k, v] : res.values) {
        std::cout << k << ": mean = " << v.first << ", std = " << v.second << std::endl;
    }

    return 0;
}

int main() {

    int status = test_score();
    return status;
}