# `mrf`

`mrf` is a Markov random field library.

## Install

You need a C99 compiler and a recent version of CMake (well, if you want to use CMake...otherwise, command line to your heart's content)

## License etc.

`mrf` is licensed under the MIT license. Enjoy! Copyright David Rushing Dewhurst, 2024 - present.
