/** 
 * @file 
 * This file is part of lppl.
 * Copyright David Rushing Dewhurst, 2022 - present.
 * Released under LGPL v3
 */

#ifndef _HL_DISTRIBUTIONS_H
#define _HL_DISTRIBUTIONS_H

#include <array>
#include <cmath>
#include <memory>

#include <heapless/rng.hpp>

struct HLNormal {
    double _loc;
    double _scale;
    HLNormal();
    HLNormal(double loc);
    HLNormal(double loc, double scale);
    double sample(XOR64PRNG * prng);
    double logprob(double value) const;
};

template<unsigned long N>
struct HLCategorical {
    std::array<double, N> _prob;
    std::array<double, N> _cumprob;
    HLCategorical() {
        static_assert(N >= 2, "Dimensionality must be >= 2");
        _prob = std::array<double, N>();
        _cumprob = std::array<double, N>();
        _prob[0] = 1.0/N;
        _cumprob[0] = _prob[0];
        for (size_t ix = 1; ix != N, ix++) {
            _prob[ix] = 1.0 / N;
            _cumprob[ix] = _prob[ix] + _cumprob[ix - 1];
        }
    };
    HLCategorical(std::array<double, N> prob) : _prob(std::move(prob)) {
        static_assert(N >= 2, "Dimensionality must be >= 2");
        _cumprob = std::array<double, N>();
        _cumprob[0] = _prob[0];
        for (size_t ix = 1; ix != N; ix++) {
            _cumprob[ix] = _prob[ix] + _cumprob[ix - 1];
        }
    };
    unsigned sample(XOR64PRNG * prng) {
        unsigned left = 0;
        unsigned right = N - 1;
        unsigned mid;
        double u = prng->uniform();

        while (left < right) {
            mid = (left + right) / 2;
            if (_cumprob[mid] < u) {
                left += 1;
            } else {
                right = mid;
            }
        }
        return left;
    };
    double logprob(unsigned value) const {
        return std::log(_prob[value]);
    };
};

struct HLGamma {
    double _k;
    double _theta;
    HLNormal _norm;
    HLGamma();
    HLGamma(double theta);
    HLGamma(double k, double theta);
    double sample(XOR64PRNG * prng);
    double logprob(double value) const;
};

#endif  // _HL_DISTRIBUTIONS_H
