/** 
 * @file 
 * This file is part of lppl.
 * Copyright David Rushing Dewhurst, 2022 - present.
 * Released under LGPL v3
 */

#include <array>
#include <string>
#include <type_traits>

#include <distributions.hpp>

#ifndef PLATE_H
#define PLATE_H


template<typename D>
struct plate {
    using DistValueType = decltype(std::declval<D>().sample(__COMPILERNG__));
    D dist;

    template<typename... Ts>
    plate(Ts... ts) {
        dist = D(ts...);
    }
};

/**
 * @brief Defines a generic plated distribution (i.e., product of independent distributions
 * with equal law)
 * 
 * @tparam D the underlying distribution type
 * @tparam N the compile-time constant dimensionality of the plate
 */
template<typename D, size_t N>
struct static_plate : plate<D> {

    /**
     * @brief Construct a new static plate.
     * 
     * Forwards all passed arguments to D constructor.
     * 
     * @tparam Ts
     * @param ts arguments to pass to underlying distribution
     */
    template<typename... Ts>
    static_plate(Ts... ts) : plate<D>(ts...) {}

    template<typename RNG>
    std::array<typename plate<D>::DistValueType, N> sample(RNG& rng) {
        std::array<typename plate<D>::DistValueType, N> out;
        for (size_t ix = 0; ix != N; ix++) {
            out[ix] = this->dist.sample(rng);
        }
        return out;
    }

    double logprob(std::array<typename plate<D>::DistValueType, N> value) {
        double out = 0.0;
        for (size_t ix = 0; ix != N; ix++) out += this->dist.logprob(value[ix]);
        return out;
    }

    std::string string() const {
        return "static_plate<" + this->dist.string() + ", " + std::to_string(N) + ">";
    }

};

#endif  // PLATE_H