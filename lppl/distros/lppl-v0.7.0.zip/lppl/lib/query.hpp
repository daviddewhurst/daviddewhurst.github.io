/**
 * \file
 * This file is part of lppl.
 * Copyright David Rushing Dewhurst, 2022 - present.
 * Released under LGPL v3
 */

#ifndef QUERY_H
#define QUERY_H

#include <cstddef>
#include <initializer_list>
#include <limits>
#include <memory>
#include <optional>
#include <string>
#include <unordered_map>
#include <utility>

#include <distributions.hpp>
#include <record.hpp>

/**
 * @brief Options used by all inference algorithms.
 * 
 */
struct inf_options_t {
    size_t _num_iterations;
};

/**
 * @brief Interface to all querying mechanisms for sample-based inference (and possibly other
 *  inference algorithms). Much computation that is associated with inference is implemented
 *  by subclasses of Queryer (rather than in inference algorithms themselves, as is often done).
 * 
 * @tparam V The type that will be returned when the emit method is called
 * @tparam O The type returned by the probabilistic program that will be queried
 * @tparam Ts The types of distributions in the probabilistic program that will be queried
 */
template<typename V, typename O, typename... Ts>
class Queryer {
    public:
        /**
         * @brief Updates the state of the queryer. 
         * 
         * @param r a record with state set by the probabilistic program being queried
         * @param output the output of the probabilistic program being queried
         * @param weight the weight associated with the query. The weight will be interpreted
         *  as the posterior log probability of the record.
         * @param opts inference options passed to the inference algorithm
         */
        virtual void update(record_t<Ts...>& r, O output, double weight, inf_options_t opts) = 0;
        
        /**
         * @brief Emits the result of the query.
         * 
         */
        virtual V emit() = 0;
};

/**
 * @brief streaming logsumexp computation, see https://arxiv.org/abs/1805.02867
 * 
 * 
 * @param _alpha running maximum for normalization
 * @param _r the sum term while controlling for the maximum
 * @param weight the most recent (log) weight
 * @return double 
 */
double logsumexp_streaming(double& _alpha, double& _r, double weight) {
    if (weight <= _alpha) {
        _r += std::exp(weight + _alpha);
    } else {
        _r *= std::exp(_alpha - weight);
        _r += 1.0;
        _alpha = weight;
    }
    return std::log(_r) + _alpha;
};

/**
 * @brief Abstract class from which weighted queryers should derive.
 * 
 * Subclassing Weighted gives access to streasming log-sub-exp weight calculations
 * 
 * @tparam V Type returned by the queryer
 * @tparam O Output type of the probabilistic program over which to do inference
 * @tparam Ts Types in the program
 */
template<typename V, typename O, typename... Ts>
class Weighted : public Queryer<V, O, Ts...> {
    protected:
        std::vector<double> w;
        double _lse_weights;
        double _alpha;
        double _r;
    public:
        Weighted() : _lse_weights(0.0), _alpha(-std::numeric_limits<double>::infinity()), _r(0.0) {}
        friend double logsumexp_streaming(double& _alpha, double& _r, double weight);
        /**
         * @brief Computes \f$\log Z = \log \sum_{1 \leq n \leq N} w_n \f$.
         * 
         * The interpretation of this number depends on the inference algorithm used with the queryer.
         * If an importance sampling algorithm is used, this is the evidence. This number should always
         * be equal to 1 when using a MCMC algorithm.
         * 
         * @param r the record to use for computing the weight
         * @param output the output of the program (unused, for API compliance)
         * @param weight the log weight associated with the record
         * @param opts the inference options
         */
        void update(record_t<Ts...>& r, O output, double weight, inf_options_t opts) {
            _lse_weights = logsumexp_streaming(_alpha, _r, weight);
            w.push_back(weight);
        }
        /**
         * @brief Resets all values associated with the queryer.
         * 
         */
        void clear() {
            _lse_weights = 0.0;
            _alpha = -std::numeric_limits<double>::infinity();
            _r = 0.0;
            w.clear();
        }
        /**
         * @brief Returns \f$\log Z = \log \sum_{1 \leq n \leq N} w_n \f$.
         * 
         * The interpretation of this number depends on the inference algorithm used with the queryer.
         * If an importance sampling algorithm is used, this is the evidence. This number should always
         * be equal to 1 when using a MCMC algorithm.
         * 
         * @return double 
         */
        double lse_weights() { return _lse_weights; }
};


template<typename V, typename O, template<class, class, class...> class Q, typename... Ts>
using queryer_map_t = std::unordered_map<std::string, std::shared_ptr<Q<V, O, Ts...>>>;

// /**
//  * @brief Collects multiple queryers, each with the same site value type and probabilistic program output type.
//  *  Returns a unique pointer to a map from address to query return value.
//  * 
//  */
template<typename V, typename O, template<class, class, class...> class Q, typename... Ts>
class QueryerCollection : public Queryer<std::unique_ptr<std::unordered_map<std::string, V>>, O, Ts...> {
    protected:
        std::vector<std::string> _ids;
        queryer_map_t<V, O, Q, Ts...> _queryers;
    public:
        QueryerCollection(std::initializer_list<std::string> ids) : _ids(ids) {
            _queryers = queryer_map_t<V, O, Q, Ts...>();
            for (const auto& id : _ids) {
                auto q = std::make_shared<Q<V, O, Ts...>>(id);
                _queryers.emplace(id, q);
            }
        }
        void update(record_t<Ts...>& r, O output, double weight, inf_options_t opts) {
            for (const auto& id : _ids) _queryers[id]->update(r, output, weight, opts);
        }
        std::unique_ptr<std::unordered_map<std::string, V>> emit() {
            auto map = std::make_unique<std::unordered_map<std::string, V>>();
            for (const auto& id : _ids) (*map)[id] = _queryers[id]->emit();
            return map;
        }
};  

// TODO [priority:MED]
// WeightedSample -- copies of values at an address along with their (log) sample weight.
//   should expose a method of random sampling from the collection
// HPDS -- should return the highest posterior density set composed of copies of records
// HPDI -- should return the highest posterior density interval [l, h] for an address
// Relational -- should return copies of values or records where a relation is satisfied
//   along with their (long) sample weights. Should expose a method fo random sampling from
//   the collection.
// Probability -- estimate probability of event from discrete random variable 

struct collection_t { Categorical _c; };

/**
 * @brief Collects records generated by an inference algorithm into an empirical posterior
 *  distribution over records and output values
 * 
 * @tparam O the output type of the probabilistic program to be queried
 * @tparam Ts the types in the probabilistic program
 */
template<typename O, typename... Ts>
struct record_collection_t : collection_t {
    std::vector<record_t<Ts...>> _v;
    std::vector<O> _o;

    record_collection_t(record_collection_t<O, Ts...>&& other) {
        _v = other._v;
        _o = other._o;
        this->_c = other._c;

        other._v = std::vector<record_t<Ts...>>();
        other._o = std::vector<O>();
        other._c = Categorical();
    }

    record_collection_t(std::vector<record_t<Ts...>> v, std::vector<O> o, Categorical c) 
        : _v(std::move(v)) {}

    /**
     * @brief Samples from the distribution over records
     * 
     * @tparam RNG type of the passed rng
     * @param rng an rng to use for sampling
     * @return std::shared_ptr<record_t<Ts...>> 
     */
    template<typename RNG>
    std::shared_ptr<record_t<Ts...>> sample(RNG& rng) {
        return std::make_shared<record_t<Ts...>>(_v[this->_c.sample(rng)]);
    }

    template<typename RNG>
    std::shared_ptr<record_t<Ts...>> sample_output(RNG& rng) {
        return std::make_shared<O>(_o[this->_c.sample(rng)]);
    }

};

/**
 * @brief A collection of weighted records. This is the "traditional" empirical posterior distribution
 *  as implemented by many trace-based probabilistic programming languages. The memory use of this 
 *  object scales as O(num_samples).
 * 
 */
template<typename, typename O, typename... Ts>
class WeightedRecord : public Weighted<std::unique_ptr<record_collection_t<O, Ts...>>, O, Ts...> {
    protected:
        std::vector<record_t<Ts...>> v;
        std::vector<O> o;
    public:
        void update(record_t<Ts...>& r, O output, double weight, inf_options_t opts) {
            Weighted<std::unique_ptr<record_collection_t<O, Ts...>>, O, Ts...>::update(r, output, weight, opts);
            // _lse_weights = logsumexp_streaming(_alpha, _r, weight);
            // w.push_back(weight);
            // aware of copy overhead, unavoidable since need to access all records after inference
            v.push_back(r);
            o.push_back(output);
        }
        std::unique_ptr<record_collection_t<O, Ts...>> emit() {
            // w_n = w'_n / sum w'_n = exp(log w'_n - log sum w'_n) = exp( weight_n - logsumexp weight_n)
            for (size_t ix = 0; ix != this->w.size(); ix++) this->w[ix] = std::exp(this->w[ix] - this->_lse_weights);
            auto c = Categorical(std::move(this->w));
            return std::make_unique<record_collection_t<O, Ts...>>(v, o, c);
        }
};

/**
 * @brief Factory function for WeightedRecord
 * 
 */
template<typename O, typename... Ts>
auto weighted_record() {
    return std::make_unique<WeightedRecord<std::unique_ptr<record_collection_t<O, Ts...>>, O, Ts...>>();
}


/**
 * @brief Computes the mean of the specified sample site. The memory usage of this object is O(1).
 * 
 */
template<typename, typename O, typename... Ts>
class WeightedMean : public Weighted<double, O, Ts...> {
    protected:
        std::string _address;
        double _mean;
    public:
        WeightedMean(std::string address) : _address(address), _mean(0.0) {}
        void update(record_t<Ts...>& r, O output, double weight, inf_options_t opts) {
            auto get_value = [](auto node) -> unique_variant_t<var_ret_t<Ts...>> { return node.value; };
            if (r.map.contains(_address)) {
                auto value = std::visit(get_value, r.map[_address]);
                if (std::holds_alternative<double>(value)) {
                    Weighted<double, O, Ts...>::update(r, output, weight, opts);
                    _mean += std::exp(weight - this->_lse_weights) * (std::get<double>(value) - _mean);
                }
            }
        }
        double emit() {
            return _mean;
        }
};

/**
 * @brief factory function for WeightedMean
 * 
 */
template<typename O, typename... Ts>
auto weighted_mean(std::string address) {
    return std::make_unique<WeightedMean<double, O, Ts...>>(address);
}

#endif  // QUERY_H
