/* 
 * This file is part of lppl.
 * Copyright David Rushing Dewhurst, 2022 - present.
 * Released under LGPL v3
 */

#include <stdint.h>

#include <heapless/rng.hpp>

XOR64PRNG::XOR64PRNG(uint64_t x) : state(XOR64State{x}) {}

uint64_t XOR64PRNG::operator()() {
    uint64_t x = state.x;
    x ^= x >> 12;
    x ^= x << 25;
    x ^= x >> 27;
    state.x = x;
    return x * 0x2545F4914F6CDD1DULL;
}

double XOR64PRNG::uniform() {
    return operator()() * __POW2_M64;
}


