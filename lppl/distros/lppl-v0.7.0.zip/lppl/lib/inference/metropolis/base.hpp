/** 
 * @file 
 * This file is part of lppl.
 * Copyright David Rushing Dewhurst, 2022 - present.
 * Released under LGPL v3
 */

#ifndef METRO_BASE_H
#define METRO_BASE_H

#include <iostream>
#include <cstddef>
#include <cmath>
#include <functional>
#include <memory>
#include <optional>
#include <random>
#include <unordered_map>

#include <distributions.hpp>
#include <record.hpp>
#include <effects.hpp>
#include <query.hpp>

template<typename... Ts>
struct MetropolisState {
    Uniform u;
    record_t<Ts...> r;
    std::minstd_rand rng;

    MetropolisState(unsigned seed=2022) : rng(seed) {};

    double log_u() {
        return std::log(u.sample(rng));
    }
};

/**
 * @brief Log acceptance probability for use when proposing from the prior
 * 
 * @tparam Ts the distribution types contained in each record
 * @param orig_r the current record
 * @param new_r the proposed new record
 * @return double log acceptance probability
 */
template<typename... Ts>
double log_accept_prior(record_t<Ts...>& orig_r, record_t<Ts...>& new_r) {
    double new_ll = loglikelihood(new_r);
    double old_ll = loglikelihood(orig_r);
    return new_ll - old_ll;
}

/**
 * @brief inf_options_t augmented with metropolis-specific arguments:
 * 
 * thin: every thin-th sample is kept in the posterior...
 * burn: ...after the burn-th sample
 * seed: seeds the prng used for acceptance/rejection
 * 
 */
struct metro_options_t : inf_options_t {
    size_t _thin;
    size_t _burn;
    size_t _num_iterations;
    size_t _n;
    unsigned _seed;

    metro_options_t(size_t thin, size_t burn, size_t num_iterations, unsigned seed=2022)
        : _num_iterations(num_iterations), _n(0), _thin(thin), _burn(burn), _seed(seed) {}
};

template<typename I, typename O, typename V, template<class, class, class...> class Q, typename... Ts>
void ancestor_metropolis_step(MetropolisState<Ts...>& state, pp_t<I, O, Ts...> f, Q<V, O, Ts...>& queryer, I input, metro_options_t opts) {
    record_t<Ts...> new_r;
    O o = f(new_r, input);
    double log_accept = log_accept_prior(state.r, new_r);
    if (state.log_u() < log_accept) state.r = new_r;
    if ((opts._n > opts._burn) && (opts._n % opts._thin == 0)) {
        queryer.update(state.r, o, 0.0, opts);
    }
}

/**
 * @brief Metropolis Hastings using the prior distribution as the proposal.
 * 
 * Suppose the generative model factors as \f$ p(x,z) = p(x|z)p(z) \f$.
 * The acceptance ratio is \f$ \log \alpha = \log p(x|z') - \log p(x|z) \f$, where
 * \f$ z' \sim p(z) \f$ is the new draw from the prior, and \f$ z \sim p(z) \f$ is the
 * old/existing draw from the prior. Each weight passed to the queryer is \f$ \log w = 0 \f$.
 * 
 * @tparam I The input type of the program on which to perform inference
 * @tparam O The output type of the program on which to perform inference
 * @tparam V The type emitted by the queryer
 * @tparam Q The queryer type
 * @tparam Ts The collection of types used in the probabilistic program
 * @param f The probabilistic program to be queried
 * @param queryer the instantiated queryer class
 * @param input the input to the probabilistic program
 * @param opts metropolis-specific inference options
 * @return V the result of calling the queryer's emit method
 */
template<typename I, typename O, typename V, template<class, class, class...> class Q, typename... Ts>
V ancestor_metropolis(pp_t<I, O, Ts...>& f, Q<V, O, Ts...>& queryer, I input, metro_options_t opts) {
    auto state = MetropolisState<Ts...>(opts._seed);
    f(state.r, input);
    while (opts._n != opts._num_iterations) {
        ancestor_metropolis_step(state, f, queryer, input, opts);
        opts._n++;
    }
    return queryer.emit();
}



#endif  // METRO_BASE_H