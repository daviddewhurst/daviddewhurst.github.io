/**
 * \file
 * This file is part of lppl.
 * Copyright David Rushing Dewhurst, 2023 - present.
 * Released under GPL v3
 */

#include <unordered_map>
#include <variant>

#include <record.hpp>

#ifndef UPDATE_H
#define UPDATE_H

/**
 * @brief A unordered map with value type equal to a sum type of input type
 * and one or more distribution types, parameterized by an update Policy.
 * 
 * The Policy parameter defines an injection 
 * \f$policy: \{D_i\}_{i \in I} \rightarrow \{D_j\}_{j \in J}\f$,
 * \f$J \subseteq I\f$.
 * This is implemented as `typename Policy<D>::type`,
 * which may be a bijection (e.g., when updating parameters in the same
 * distributional family) or may not (e.g., a normal approximation).
 * 
 * @tparam Policy encapsulates the types of distributions that can be returned
 *  by `get`. Must define `type` with a using-declaration.
 * @tparam I The input type
 * @tparam Ds The universe of allowable distribution types
 */
template<
    template<typename> class Policy,
    typename I,
    typename... Ds
>
struct typed_map {
    using input_or_dists = std::variant<I, Ds...>;
    std::unordered_map<std::string, input_or_dists> map_;
    
    void insert_or_assign(std::string name, input_or_dists obj) { map_.insert_or_assign(name, obj); }

    /**
     * @brief Return a value or distribution according to the policy parameter.
     * 
     * @tparam D input or distribution type intended in original program semantics
     * @param name the address to query
     * @return Policy<D>::type an object with type specified by the policy.
     */
    template<typename D>
    typename Policy<D>::type extract(std::string name) {
        return std::get<typename Policy<D>::type>(map_[name]);
    }

};

/**
 * @brief Alias to probabilistic programs that take typed_map references
 * as inputs.
 * 
 * @tparam Policy encapsulates the types of distributions that can be returned
 *  by `get`. Must define `type` with a using-declaration.
 * @tparam I the input type
 * @tparam O the output type
 * @tparam Ts The universe of allowable distribution types
 */
template<
    template<typename> class Policy,
    typename I,
    typename O,
    typename... Ts
>
using upp_t = pp_t<typed_map<Policy, I, Ts...>&, O, Ts...>;


/**
 * @brief *Experimental* base class of `typed_map`-based update logic.
 * 
 * @tparam Impl Implementation template template
 * @tparam Policy encapsulates the types of distributions that can be returned
 *  by `get`. Must define `type` with a using-declaration.
 * @tparam QueryResult the type returned from the desired queryer.
 * @tparam I The input type
 * @tparam Ts The universe of allowable distribution types
 */
template<
    template <
        template<typename> class,
        typename,
        typename,
        typename...
    > class Impl,
    template<typename> class Policy,
    typename QueryResult,
    typename I,
    typename O,
    typename... Ts
>
struct Update {

    upp_t<Policy, I, O, Ts...>& f;

    /**
     * @brief Calls derived implementation.
     * 
     * @param result the result from a queryer.
     * @return typed_map<Policy, I, Ts...> 
     */
    typed_map<Policy, I, Ts...> operator()(QueryResult& result) {
        return static_cast<Impl<Policy, QueryResult, I, O, Ts...>*>(this)->operator()(result);
    }
};

/**
 * @brief Factory function for Updater.
 * 
 * @param f A `upp_t` for which updates may be performed.
 * @return Update<Impl, Policy, QueryResult, I, O, Ts...> 
 */
template<
    template <
        template<typename> class,
        typename,
        typename,
        typename...
    > class Impl,
    template<typename> class Policy,
    typename QueryResult,
    typename I,
    typename O,
    typename... Ts
>
Update<Impl, Policy, QueryResult, I, O, Ts...>
update(upp_t<Policy, I, O, Ts...>& f) {
    return Update<Impl, Policy, QueryResult, I, O, Ts...>(f);
}

/**
 * @brief Sample a value from the addressed distribution in the `typed_map`
 * 
 * For example,
 * ```
 * auto loc = sample_u<Normal>(r, "loc", input, rng);
 * ```
 * corresponds to the semantics "sample the value for "loc" from the distribution contained
 * in the map; my prior belief is that that distribution is Normal".
 * 
 * @tparam D Type of the originally intended distribution
 * @tparam RNG Type of the PRNG
 * @tparam Policy encapsulates the types of distributions that can be returned
 *  by `get`. Must define `type` with a using-declaration.
 * @tparam I the input type
 * @tparam Ts the universe of allowable distribution types
 * @param r the record into which to sample
 * @param address the address at which to store the sample
 * @param map_ the `typed_map` containing the distribution from which to sample
 * @param rng the PRNG used to construct the sample
 * @return DSType<typename Policy<D>::type> 
 */
template<typename D, typename RNG, template<typename> class Policy, typename I, typename... Ts>
DSType<typename Policy<D>::type> sample_u(record_t<Ts...>& r, std::string address, typed_map<Policy, I, Ts...>& map_, RNG& rng) {
    return sample(r, address, map_.template extract<D>(address), rng);
}

/**
 * @brief Observe a value from data contained in the `typed_map`.
 * 
 * @tparam V The type of the value to observe
 * @tparam D The type of distribution against which to post evidence
 * @tparam Policy encapsulates the types of distributions that can be returned
 *  by `get`. Must define `type` with a using-declaration.
 * @tparam I the input type
 * @tparam Ts the universe of allowable distribution types
 * @param r the record into which to observe
 * @param address the address at which to store the observation
 * @param dist the distribution against which to post evidence
 * @param map_ the `typed_map` containing the evidence
 * @return V 
 */
template<typename V, typename D, template<typename> class Policy, typename I, typename... Ts>
V observe_u(record_t<Ts...>& r, std::string address, D dist, typed_map<Policy, I, Ts...>& map_) {
    return observe(r, address, dist, map_.template extract<V>(address));
}

#endif  // UPDATE_H