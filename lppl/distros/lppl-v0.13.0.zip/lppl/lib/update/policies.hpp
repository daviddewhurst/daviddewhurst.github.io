/**
 * \file
 * This file is part of lppl.
 * Copyright David Rushing Dewhurst, 2023 - present.
 * Released under GPL v3
 */

#include <distributions.hpp>
#include <update.hpp>

#ifndef UPDATE_POLICIES_H
#define UPDATE_POLICIES_H

/// \todo -- figure out open vs closed universe and representations of their semantics

/**
 * @brief identity function between sets of distributions
 * 
 * @tparam D Input distribution type.
 */
template<typename D>
struct DefaultPolicy {
    using type = D;
};

/**
 * @brief Every distribution type is approximated by a normal distribution.
 * 
 * @tparam D Input distribution type.
 */
template<typename D>
struct NormalPolicy {
    using type = Normal;
};


#endif  // UPDATE_POLICIES_H
