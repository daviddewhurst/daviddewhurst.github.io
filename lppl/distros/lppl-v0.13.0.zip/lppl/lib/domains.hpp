/**  
 * @file
 * This file is part of lppl.
 * Copyright David Rushing Dewhurst, 2023 - present.
 * Released under GPL v3
 */

template<typename T>
struct unbounded {
    using type = T;
};

template<typename T>
struct non_negative {
    using type = T;
    constexpr static T lower_bound = 0;
};

template<typename T, T lower, T upper>
struct bounded {
    using type = T;
    constexpr static T lower_bound = lower;
    constexpr static T upper_bound = upper;
};
