/* 
 * This file is part of lppl.
 * Copyright David Rushing Dewhurst, 2022 - present.
 * Released under GPL v3
 */

#define _USE_MATH_DEFINES

#include "distributions.hpp"

#include <cstddef>
#include <string>
#include <random>
#include <cmath>
#include <sstream>
#include <vector>

using namespace Distributions;

DiscreteUniform::DiscreteUniform(const int low, const int high)
    : StdDistribution<int, std::uniform_int_distribution<>>(
        std::uniform_int_distribution(low, high))
        {
            _high = high;
            _low = low;
        }

DiscreteUniform::DiscreteUniform(int high)
    : DiscreteUniform(0, high) {}

DiscreteUniform::DiscreteUniform()
    : DiscreteUniform(0, 1) {}

double DiscreteUniform::logprob(int) const {
    return -std::log(_high - _low + 1.0);
}

std::string DiscreteUniform::string() {
    return "DiscreteUniform(low=" + std::to_string(_low) + ", high=" + std::to_string(_high) + ")";
}

// Uniform 

Uniform::Uniform(double low, double high)
    : StdDistribution<double, std::uniform_real_distribution<>>(
        std::uniform_real_distribution(low, high))
        {
            _high = high;
            _low = low;
        }

Uniform::Uniform(double high)
    : Uniform(0.0, high) {}

Uniform::Uniform()
    : Uniform(0.0, 1.0) {}

double Uniform::logprob(double) const {
    return -std::log(_high - _low);
}

std::string Uniform::string() const {
    return "Uniform(low=" + std::to_string(_low) + ", high=" + std::to_string(_high) + ")";
}

// Normal

Normal::Normal(double loc, double scale) 
    : StdDistribution<double, std::normal_distribution<>>(std::normal_distribution<>(loc, scale)) {
    _loc = loc;
    _scale = scale;
    _log_Z = 0.5 * std::log(2.0 * M_PI) + std::log(_scale);
}
Normal::Normal(double loc) : Normal(loc, 1.0) {}
Normal::Normal() : Normal(0.0, 1.0) {}

double Normal::get_loc() {
    return _loc;
}

double Normal::get_scale() {
    return _scale;
}

std::string Normal::string() const {
    std::string str_loc = std::to_string(_loc);
    std::string str_scale = std::to_string(_scale);
    return "Normal(loc=" + str_loc + ", scale=" + str_scale + ")";
}

double Normal::logprob(double value) const {
    double std_score = (value - _loc) / _scale;
    return -0.5 * std::pow(std_score, 2.0) - _log_Z;
}


// Categorical 

std::vector<double> _to_uniform_vector(int dim) {
    std::vector<double> probs;
    for (int i = 0; i != dim; i++) {
        probs.push_back(1.0 / dim);
    }
    return probs;
}

Categorical::Categorical(std::vector<double> probs)
    : StdDistribution<unsigned long, std::discrete_distribution<int>>(std::discrete_distribution<int>(probs.begin(), probs.end())) {
    _probs = probs;
}
Categorical::Categorical(int dim) : Categorical(_to_uniform_vector(dim)) {}
Categorical::Categorical() : Categorical(2) {}

double Categorical::at(size_t ix) {
    return _probs[ix];
}

std::vector<double> Categorical::get_probs() {
    return _probs;
}

unsigned long Categorical::get_dim() {
    return _probs.size();
}

std::string Categorical::string() const {
    std::stringstream ss;
    ss << "[";
    for ( size_t i = 0; i != _probs.size(); i++) {
        if (i != 0) {
            ss << ",";
        }
        ss << _probs[i];
    }
    ss << "]";
    std::string str_probs = ss.str();
    return "Categorical(probs=" + str_probs + ")";
}

double Categorical::logprob(unsigned long value) const {
    return std::log(_probs[value]);
}

Gamma::Gamma(double k, double theta)
    : StdDistribution<double, std::gamma_distribution<double>>(std::gamma_distribution<double>(k, theta)) {
    _k = k;
    _theta = theta;
    _log_Z = _k * std::log(_theta) + lgamma(_k);
}
Gamma::Gamma(double theta) : Gamma::Gamma(1.0, theta) {}
Gamma::Gamma() : Gamma::Gamma(1.0, 1.0) {}

double Gamma::get_k() { return _k; }
double Gamma::get_theta() { return _theta; }

std::string Gamma::string() const {
    return "Gamma(k=" + std::to_string(_k) + ", theta=" + std::to_string(_theta) + ")";
}

double Gamma::logprob(double val) const {
    return (_k - 1.0) * std::log(val) - val / _theta - _log_Z;
}


Beta::Beta(double alpha, double beta)
    : _alpha(alpha), _beta(beta), alpha_dist(Gamma(alpha, 1)), beta_dist(Gamma(beta, 1)) {}

double Beta::get_alpha() {
    return _alpha;
}

double Beta::get_beta() {
    return _beta;
}

std::string Beta::string() const {
    return "Beta(alpha=" + std::to_string(_alpha) + ", beta=" + std::to_string(_beta) + ")";
}

double Beta::logprob(double value) const {
    return (_alpha - 1) * std::log(value) + (_beta - 1) * std::log(1 - value) + std::lgamma(_alpha + _beta) - std::lgamma(_alpha) - std::lgamma(_beta);
}


Poisson::Poisson(double rate) 
    : StdDistribution<unsigned, std::poisson_distribution<unsigned>>(std::poisson_distribution<unsigned>(rate)) {
    if (rate > 0.0) {
        _rate = rate;
    } else {
        _rate = 0.0;
    }
}
Poisson::Poisson() : Poisson(1.0) {}

double Poisson::get_rate() { return _rate; }

std::string Poisson::string() const {
    return "Poisson(rate=" + std::to_string(_rate) + ")";
}

double Poisson::logprob(unsigned value) const {
    return -_rate + value * std::log(_rate) - lgamma(value + 1.0);
}
