# `lppl`

Stands for "last probabilistic programming language" because eventually I have to write something other than PPLs.

Homepage: https://davidrushingdewhurst.com/lppl/ 

## Build
`cd build && cmake .. && make`. Unsurprisingly, this requires cmake. On a less obvious note, building `lppl` requires (a) a compiler that supports C++ 20 and (b) CMake v3.20.0 or later. 

**Please note** that `lppl` has been tested on Apple clang v12.0.0 and Mingw-w64 (unknown version). It *should* compile under any standards compliant C++20 compiler, but that is not guaranteed. Please submit build errors here: https://gitlab.com/drdewhurst/lppl/-/issues. 

## Test
Run any of the tests that show up in the `build` directory after you build. E.g., `./record_test`. **Please note** that deterministic results are guaranteed under specific hardware configurations, but not across operating systems.

## Documentation
Here: https://davidrushingdewhurst.com/lppl/docs/index.html  

## Examples
Here: https://davidrushingdewhurst.com/lppl/examples/

## License etc.

`lppl` is licensed under the MIT license. Enjoy! Copyright David Rushing Dewhurst, 2022 - present.
