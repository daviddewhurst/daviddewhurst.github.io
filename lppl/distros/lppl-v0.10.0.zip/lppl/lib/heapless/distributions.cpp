/* 
 * This file is part of lppl.
 * Copyright David Rushing Dewhurst, 2022 - present.
 * Released under GPL v3
 */

#define _USE_MATH_DEFINES

#include <heapless/rng.hpp>
#include <heapless/distributions.hpp>

#include <stdint.h>
#include <cmath>

#define __TWO_PI 2.0 * M_PI

HLNormal::HLNormal() : _loc(0.0), _scale(1.0) {}
HLNormal::HLNormal(double loc) : _loc(loc), _scale(1.0) {}
HLNormal::HLNormal(double loc, double scale) : _loc(loc), _scale(scale) {}

double HLNormal::sample(XOR64PRNG * prng) {
    double u = prng->uniform();
    // this is inefficient and we'd want to save the second value somewhere
    double v = prng->uniform();  
    return _loc + _scale * std::sqrt(-2.0 * std::log(u)) * std::cos(__TWO_PI * v);
}

double HLNormal::logprob(double value) const {
    return -0.5 * std::pow((value - _loc) / _scale, 2.0) - (
        0.5 * std::log(__TWO_PI) + std::log(_scale)
    );
}

HLGamma::HLGamma() : _k(1.0), _theta(1.0), _norm(HLNormal()) {}
HLGamma::HLGamma(double theta) : _k(1.0), _theta(theta), _norm(HLNormal()) {}
HLGamma::HLGamma(double theta, double k) : _k(k), _theta(theta), _norm(HLNormal()) {}

double HLGamma::sample(XOR64PRNG * prng) {
    // first generate a Gamma(k, 1), then get Gamma(k, theta) by scaling
    // using Marsaglia's method -- base case works for k > 1
    // requires two rvs -- n ~ Normal(0, 1), u ~ Uniform (0, 1);
    double n, u;

    // computation of some intermediates as a function of k
    double local_k = _k > 1.0 ? _k : _k + 1.0;
    double d = local_k - 1.0/3.0;
    double c = 1.0 / std::sqrt(9.0 * d);
    double v, d_times_v, gamma_k_1;

    int stop = 0;
    while (stop < 1) {
        n = _norm.sample(prng);
        v = pow(1.0 + c * n, 3.0);
        d_times_v = d * v;
        u = prng->uniform();
        if ((v > 0) & (std::log(u) < std::pow(n, 2.0)/2.0 + d - d_times_v + d * std::log(v))) {
            gamma_k_1 = d_times_v;
            stop++;
        }
    }

    // gamma_k = gamma_{k+1} * u^(1/k) per Marsaglia
    if (_k <= 1.0) {
        gamma_k_1 = gamma_k_1 * std::pow(u, 1.0 / _k);
    }

    // now use scaling property
    return gamma_k_1 * _theta;
}

double HLGamma::logprob(double value) const {
    return (_k - 1.0) * std::log(value) - value / _theta - (
        _k * std::log(_theta) + std::lgamma(_k)
    );
}
