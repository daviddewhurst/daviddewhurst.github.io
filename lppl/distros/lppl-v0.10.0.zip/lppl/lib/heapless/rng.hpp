/**
 * @file 
 * This file is part of lppl.
 * Copyright David Rushing Dewhurst, 2022 - present.
 * Released under GPL v3
 */

#ifndef _HL_RNG_H
#define _HL_RNG_H

#define __POW2_M64   5.421010862427522170037264004349e-020

#include <stdint.h>

struct XOR64State { uint64_t x; };

/**
 * @brief 
 * 
 */
struct XOR64PRNG {
    XOR64State state;
    XOR64PRNG(uint64_t x);
    uint64_t operator()();
    double uniform();
};

#endif  // _HL_RNG_H