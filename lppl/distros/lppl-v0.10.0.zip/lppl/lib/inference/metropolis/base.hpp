/** 
 * \file 
 * This file is part of lppl.
 * Copyright David Rushing Dewhurst, 2022 - present.
 * Released under GPL v3
 */

#ifndef METRO_BASE_H
#define METRO_BASE_H

#include <algorithm>
#include <iostream>
#include <cstddef>
#include <cmath>
#include <functional>
#include <memory>
#include <optional>
#include <random>
#include <unordered_map>
#include <vector>

#include <distributions.hpp>
#include <record.hpp>
#include <effects.hpp>
#include <query.hpp>

#include <inference/inference.hpp>
#include <inference/proposal.hpp>

template<typename... Ts>
struct MetropolisState {
    Uniform u;
    record_t<Ts...> r;
    std::minstd_rand rng;

    MetropolisState(unsigned seed=2022) : rng(seed) {}

    double log_u() {
        return std::log(u.sample(rng));
    }
};

/**
 * @brief Log acceptance probability for use when proposing from the prior
 * 
 * @tparam Ts the distribution types contained in each record
 * @param orig_r the current record
 * @param new_r the proposed new record
 * @return double log acceptance probability
 */
template<typename... Ts>
double log_accept_prior(record_t<Ts...>& orig_r, record_t<Ts...>& new_r) {
    double new_ll = loglikelihood(new_r);
    double old_ll = loglikelihood(orig_r);
    return new_ll - old_ll;
}

/**
 * @brief Metropolis Hastings using the prior distribution as the proposal.
 * 
 * Suppose the generative model factors as \f$ p(x,z) = p(x|z)p(z) \f$.
 * The acceptance ratio is \f$ \log \alpha = \log p(x|z') - \log p(x|z) \f$, where
 * \f$ z' \sim p(z) \f$ is the new draw from the prior, and \f$ z \sim p(z) \f$ is the
 * old/existing draw from the prior. Each weight passed to the queryer is \f$ \log w = 0 \f$.
 * 
 * @tparam I The input type of the program on which to perform inference
 * @tparam O The output type of the program on which to perform inference
 * @tparam V The type emitted by the queryer
 * @tparam Q The queryer type
 * @tparam Ts The distribution types used in the probabilistic program
 */
template<typename I, typename O, typename V, template<class, class, class...> class Q, typename... Ts>
struct AncestorMetropolis : Inference<AncestorMetropolis, I, O, V, Q, Ts...> {
    void step(MetropolisState<Ts...>& state, pp_t<I, O, Ts...> f, Q<V, O, Ts...>& queryer, I input, inf_options_t opts) {
        record_t<Ts...> new_r;
        O o = f(new_r, input);
        double log_accept = log_accept_prior(state.r, new_r);
        if (state.log_u() < log_accept) state.r = new_r;
        if ((opts._num_complete > opts._burn) && (opts._num_complete % opts._thin == 0)) {
            queryer.update(state.r, o, 0.0, opts);
        }
    }
    V operator()(I& input) {
        auto state = MetropolisState<Ts...>(this->opts._seed);
        this->f(state.r, input);
        while (this->opts._num_complete != this->opts._num_iterations) {
            step(state, this->f, this->queryer, input, this->opts);
            this->opts._num_complete++;
        }
        return this->queryer.emit();
    }
};

/**
 * @brief Computes symmetric difference and intersection of address spaces
 * 
 */
struct generic_metropolis_helper {
    std::vector<std::string> new_addrs;
    std::vector<std::string> common_addrs;

    template<typename ROrig, typename RNew>
    void new_addresses(ROrig& r_orig, RNew& r_new) {
        new_addrs.clear();
        for (auto& [k, _] : r_new.map) {
            if (!r_orig.map.contains(k)) new_addrs.push_back(k);
        }
    }

    template<typename ROrig, typename RNew>
    void intersect(ROrig& r_orig, RNew& r_new) {
        common_addrs.clear();
        const auto& [smaller, larger] = std::minmax(
            r_orig, r_new,
            [](auto& r, auto& r_prime){ return r.map.size() < r_prime.map.size(); }
        );
        for (auto& [k, _] : smaller.map) {
            if (larger.map.contains(k)) common_addrs.push_back(k);
        }
    }

};

/**
 * @brief Computes the log probability of one record given another.
 * 
 * Given two records \f$r\f$ and \f$r'\f$ with address spaces \f$A(r)\f$ and \f$A(r')\f$
 * respectively, computes the quantity \f$\log q(r'|r)\f$ by accumulating log probability from
 * two sources:
 * 
 * + \f$r'(a)\f$ where \f$a \in A(r') \triangle A(r)\f$
 * + \f$r'(a)\f$ where \f$a \in A(r') \cap A(r)\f$ and
 *  the corresponding interpretation in \f$r'\f$ is interp_t::propose.
 * 
 * @tparam ROrig The type of the original record
 * @tparam RNew The type of the new record
 * @param helper for computing symmetric differences and intersections
 * @param r_orig the original record
 * @param r_new the new record
 * @return double 
 */
template<typename ROrig, typename RNew>
double proposal_log_prob(generic_metropolis_helper& helper, ROrig& r_orig, RNew& r_new) {
    double lq = 0.0;
    auto get_logprob = [](auto& n) -> double { return n.logprob; };
    auto is_it_proposed = [](auto& n) -> bool { return n.interp == interp_t::propose; };

    helper.new_addresses(r_orig, r_new);
    for (auto& a : helper.new_addrs) {
        lq += std::visit(get_logprob, r_new.map[a]);
    }

    helper.intersect(r_orig, r_new);
    for (auto& a : helper.common_addrs) {
        // proposal's job to send this message
        if (std::visit(is_it_proposed, r_new.map[a])) {
            lq += std::visit(get_logprob, r_new.map[a]);
        }
    }
    return lq;
}

/**
 * @brief Generic Metropolis-Hastings algorithm with user-specified proposal distribution.
 * 
 * Suppose the probabilistic program factors as \f$p(x, z) = p(x|z)p(z)\f$ and the proposal distribution
 * takes the form \f$q(z'|z)\f$. The log acceptance ratio is computed as
 * \f$ \log \alpha = [\log p(x, z') - \log q(z' | z)] - [\log p(x, z) - \log q(z | z')]\f$, where
 * \f$z' \sim q(z'|z)\f$ are the newly generated unobserved rvs.
 * The proposal distribution need not be symmetric.
 * 
 * @tparam I The input type of the probabilistic program
 * @tparam O The output type of the probabilistic program
 * @tparam V The type of the value to be queried
 * @tparam Q The queryer class template
 * @tparam Ts The types of the distributions in the probabilistic program
 */
template<typename I, typename O, typename V, template<class, class, class...> class Q, typename... Ts>
struct GenericMetropolis : Inference<GenericMetropolis, I, O, V, Q, Ts...> {
    template<typename P>
    void step(
        MetropolisState<Ts...>& state,
        pp_t<I, O, Ts...> f,
        Q<V, O, Ts...>& queryer,
        P& proposal,
        generic_metropolis_helper& helper,
        I input,
        inf_options_t opts
    ) {
        auto r_new = proposal(state.r);
        // populate the rest of the values...
        O o = f(r_new, input);
        double log_q_new_given_old = proposal_log_prob(helper, state.r, r_new);
        double log_q_old_given_new = proposal_log_prob(helper, r_new, state.r);
        double log_accept = logprob(r_new) + log_q_old_given_new - logprob(state.r) - log_q_new_given_old;
        if (state.log_u() < log_accept) state.r = r_new;
        if ((opts._num_complete > opts._burn) && (opts._num_complete % opts._thin == 0)) {
            queryer.update(state.r, o, 0.0, opts);
        }
    }
    /**
     * @brief Runs the inference algorithm
     * 
     * @tparam P The type of the proposal kernel. P must overload operator()(record_t<Ts...>&).
     * @param input The input to the probabilistic program
     * @param proposal The proposal kernel
     * @return V 
     */
    template<typename P>
    V operator()(I& input, P& proposal) {
        // initialize internal state
        auto state = MetropolisState<Ts...>(this->opts._seed);
        generic_metropolis_helper helper;
        // populate an initial trace
        this->f(state.r, input);

        auto replayed_f = replay(this->f);
        while (this->opts._num_complete != this->opts._num_iterations) {
            step(state, replayed_f, this->queryer, proposal, helper, input, this->opts);
            this->opts._num_complete++;
        }
        return this->queryer.emit();
    }
};

template<>
struct has_proposal<GenericMetropolis> {
    static constexpr bool value = true;
};

#endif  // METRO_BASE_H
