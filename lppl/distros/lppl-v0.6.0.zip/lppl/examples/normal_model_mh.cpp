/* 
 * This file is part of lppl.
 * Copyright David Rushing Dewhurst, 2022 - present.
 * Released under LGPL v3
 */

// #include <chrono>
#include <random>
#include <string>

#include <distributions.hpp>
#include <record.hpp>
#include <inference/metropolis/base.hpp>


struct my_state {
    std::minstd_rand rng;
    double data;

    my_state(double data)
        : rng(2022), data(data) {}

};

double my_pp(record_t<Normal, Gamma>& r, std::shared_ptr<my_state> state) {
    auto loc = sample(r, "loc", Normal(0.0, 3.0), state->rng);
    auto scale = sample(r, "scale", Gamma(), state->rng);
    auto obs = observe(r, "obs", Normal(loc, scale), state->data);
    return std::pow(obs, 2.0);
}

int main(int argc, char ** argv) {
    auto s = std::make_shared<my_state>(-3.0);
    pp_t<std::shared_ptr<my_state>, double, Normal, Gamma> f = my_pp;
    auto q = weighted_mean<double, Normal, Gamma>("loc");

    size_t thin = 25;
    size_t burn = 500;
    size_t nsamp = 25;
    auto opts = metro_options_t(thin, burn, burn + thin * nsamp);

    // auto start_time = std::chrono::high_resolution_clock::now();
    auto post_mean = ancestor_metropolis(f, *q, s, opts);
    // auto elapsed = std::chrono::high_resolution_clock::now() - start_time;
    // auto millis = std::chrono::duration_cast<std::chrono::milliseconds>(elapsed).count();
}
