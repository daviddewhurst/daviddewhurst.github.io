/* 
 * This file is part of lppl.
 * Copyright David Rushing Dewhurst, 2022 - present.
 * Released under LGPL v3
 */

#include <distributions.hpp>
#include <record.hpp>
#include <inference/proposal.hpp>
#include <inference/importance/generic.hpp>
#include <plate.hpp>
#include <query.hpp>

#include <iostream>
#include <random>
#include <string>
#include <vector>


using namespace Distributions;

std::minstd_rand rng(202);


double normal_model(record_t<Normal>& r, double obs_val) {
    auto loc = sample(r, "loc", Normal(0.0, 1.0), rng);
    auto log_scale = sample(r, "log_scale", Normal(-1.0, 0.5), rng);
    return observe(r, "obs", Normal(loc, std::exp(log_scale)), obs_val);
}

struct my_proposal : proposal<Normal> {
    record_t<Normal> generate() {
        record_t<Normal> r;
        sample(r, "loc", Normal(0.0, 10.0), rng);
        sample(r, "log_scale", Normal(0.0, 3.0), rng);
        return r;
    }
};

int test_proposal_incremental() {

    my_proposal prop;
    auto r = prop();
    std::cout << display(r) << std::endl;

    double data = 8.0;

    pp_t<double, double, Normal> f = normal_model;
    inf_options_t opts = { ._num_iterations = 100 };

    auto record_q = weighted_record<double, Normal>();
    auto records = importance_sampling(f, *record_q, data, prop, opts);
    auto r_samp = records->sample(rng);
    std::cout << "Sampled record:\n" << display(*r_samp) << std::endl;

    auto mean_q = weighted_mean<double, Normal>("loc");
    auto mean_loc = importance_sampling(f, *mean_q, data, prop, opts);
    std::cout << "Mean loc = " << mean_loc << std::endl;

    return 0;
}


int main(int argc, char ** argv) {
    auto status = std::vector<int>({
        test_proposal_incremental()
    });
    if (*std::max_element(status.begin(), status.end()) > 0) {
        std::cout << "~~~ Test failed; read log for more. ~~~\n";
        return 1;
    } else {
        std::cout << "~~~ All tests passed. ~~~\n";
        return 0;
    }
}

