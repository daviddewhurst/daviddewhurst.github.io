/** @file
 * This file is part of lppl.
 * Copyright David Rushing Dewhurst, 2022 - present.
 * Released under LGPL v3
 */

#ifndef DISTRIBUTIONS_H
#define DISTRIBUTIONS_H

#include <iostream>
#include <limits>
#include <string>
#include <utility>
#include <vector>
#include <random>


namespace Distributions {
    
    /**
     * @brief Interface for objects that generate a value. This can correspond to
     * traced randomness, but does not have to.
     * 
     * @tparam V the type of the generated value
     */
    template<typename V>
    class Generate {
        protected:
            /**
             * @brief The method that generates a value
             * TODO [priority:HIGH] when apple clang fully supports concepts,
             * re-implement as a Callable concept
             * 
             */
            template<typename RNG, typename C>
            V generate(C& callable, RNG& rng) {
                return callable(rng);
            }
    };

    /**
     * @brief Interface for objects against which a value can be scored for log
     * probability (up to an additive constant). This can correspond to objects
     * used for traced randomness, but does not need to (e.g., improper priors,\
     * energy functions)
     * 
     * @tparam V the type of the value to be scored
     */
    template<typename V>
    class LogProb {
        protected:
            /**
             * @brief to be overridden
             * 
             */
            virtual double logprob(V value) const = 0;
    };

    /**
     * @brief Interface for objects that support generating and scoring values
     * 
     * @tparam V type of value to be generated and scored
     */
    template<typename V>
    class Distribution : protected Generate<V>, LogProb<V> {};

    /**
     * @brief Wrapper class for objects in <random> (which can be used as 
     * prngs, but don't support computation of log probability functions)
     * 
     * @tparam V type of value to be generated and scored
     * @tparam DT type of underlying distribution prng, likely but not required
     * to be in <random>
     */
    template<typename V, typename DT>
    class StdDistribution : protected Distribution<V> {
        protected:
            DT _dist;
        public:
            StdDistribution(DT dist) : _dist(dist) {};
            template<typename RNG>
            V sample(RNG& rng) {
                return Distribution<V>::generate(_dist, rng);
            }
    };

    // TODO [priority:MED] implement track function call

    /**
     * @brief A discrete uniform distribution over integers.
     * 
     */
    class DiscreteUniform : public StdDistribution<int, std::uniform_int_distribution<>> {
        public:
            DiscreteUniform();
            DiscreteUniform(int high);
            DiscreteUniform(int low, int high);
            double logprob(int value) const;
            std::string string();
        private:
            int _low;
            int _high;
    };

   /**
     * @brief A continuous uniform distribution over doubles.
     * 
     */
    class Uniform : public StdDistribution<double, std::uniform_real_distribution<>> {
        public:
            Uniform();
            Uniform(double high);
            Uniform(double low, double high);
            double logprob(double value) const;
            std::string string();
        private:
            double _low;
            double _high;
    };

    /**
     * A normal distribution parameterized by location and scale.
     * 
     * @param loc: double corresponding to location (mean)
     * @param scale: non-negative double corresponding to scale (standard deviation)
     */
    class Normal : public StdDistribution<double, std::normal_distribution<>> {

        public:
            /**
             * A normal distribution parameterized by location and scale.
             * 
             * @param loc: double corresponding to location (mean)
             * @param scale: non-negative double corresponding to scale (standard deviation)
             */
            Normal(double loc, double scale);

            /**
             * A normal disribution with unit variance.
             */ 
            Normal(double loc);

            /**
             * A normal distribution with zero mean, unit variance.
             */ 
            Normal();

            /**
             * Gets the location parameter.
             * 
             * @return double location parameter
             */
            double get_loc();

            /**
             * Gets the scale parameter.
             * 
             * @return double scale parameter.
             */ 
            double get_scale();

            /**
             * Returns a string representation of the distribution.
             * 
             * @return `std::string` representing the distribution.
             */ 
            std::string string() const;

            /**
             * The log probability of the value under the distribution. 
             * 
             * @param value the value to score
             * @return double the log probability of the value under N(loc, scale)
             */ 
            double logprob(double value) const;

        private:
            double _loc;
            double _scale;
            double _log_Z;
    };  // class Normal


    /**
     * A categorical distribution parameterized by a std::vector<double> of probabilities
     */
    class Categorical : public StdDistribution<unsigned long, std::discrete_distribution<int>> {
        private:
            std::vector<double> _probs;

        public:
            /**
             * A categorical distribution parameterized by a std::vector<double> of probabilities
             * 
             * @param std::vector<double> probs the probability vector of the categorical
             */
            Categorical(std::vector<double> probs);

            /**
             * A categorical distribution with uniform probability of selecting any of 1,...,dim
             * @param dim integer dimension, must be > 1
             */
            Categorical(int dim);

            /**
             * A bivariate categorical distribution with equal probabilities.
             */
            Categorical();

            /**
             * Get the probability vector of the categorical distribution
             */
            std::vector<double> get_probs();

            /**
             * Get the dimension of the categorical distribution
             */
            unsigned long get_dim();

            /**
             * Get a std::string representation of the categorical distribution.
             */
            std::string string() const;

            /**
             * The log probability of the value under the distribution
             * 
             * @param value the value to score under the distribution
             * @return the log probability of the value scored under the distribution
             */
            double logprob(unsigned long value) const;
    };  // class Categorical

    /**
     * A gamma distribution parameterized by shape k and scale theta.
     */
    class Gamma : public StdDistribution<double, std::gamma_distribution<double>> {
        private:
            double _k;
            double _theta;
            double _log_Z;

        public:
            /**
             * A gamma distribution parameterized by shape k and scale theta. 
             * 
             * @param k shape of the distribution
             * @param theta scale of the distribution; rate = 1/scale.
             */
            Gamma(double k, double theta);

            /**
             * A gamma distribution with k = 1; corresponds to exponential distribution with scale = theta
             *
             * @param theta scale of the distribution; rate = 1/scale.
             */
            Gamma(double theta);

            /**
             * A gamma distribution with k = theta = 1; corresponds to a standard exponential distribution.
             */
            Gamma();

            /**
             * Gets the value of the shape parameter
             */
            double get_k();

            /**
             * Gets the value of the scale parameter.
             */
            double get_theta();

            /**
             * Get a std::string representation of the categorical distribution.
             */
            std::string string() const;

            /**
             * The log probability of the value under the distribution
             * 
             * @param value the value to score under the distribution
             * @return the log probability of the value scored under the distribution
             */
            double logprob(double value) const;
    };  // class Gamma

    class Poisson : public StdDistribution<unsigned, std::poisson_distribution<unsigned>> {
        private:
            double _rate;

        public:
            Poisson(double rate);
            Poisson();

            double get_rate();

            std::string string() const;

            double logprob(unsigned value) const;

    };  // class Poisson

}  // namespace Distributions

#endif  // DISTRIBUTIONS_H
