/** 
 * \file proposal.hpp  
 * This file is part of lppl.
 * Copyright David Rushing Dewhurst, 2022 - present.
 * Released under LGPL v3
 */

#ifndef PROPOSAL_H
#define PROPOSAL_H

/**
 * @brief Abstract base class from which all proposals should inherit.
 * 
 * Subclasses must implement a single method, generate, that takes no
 * arguments and returns a record of distribution types Out...
 * 
 * @tparam Out 
 */
template<typename... Out>
struct proposal {

    /**
     * @brief To be overridden; proposes a record.
     * 
     * @return record_t<Out...> 
     */
    virtual record_t<Out...> generate() = 0;

    record_t<Out...> operator()() {
        auto r = generate();
        r.interp = __r_replay__;
        return r;
    }

};

#endif  // PROPOSAL_H