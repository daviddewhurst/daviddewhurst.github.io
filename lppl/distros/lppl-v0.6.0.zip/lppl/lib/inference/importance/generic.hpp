/** 
 * \file generic.hpp
 * This file is part of lppl.
 * Copyright David Rushing Dewhurst, 2022 - present.
 * Released under LGPL v3
 */

#ifndef IS_GENERIC_H
#define IS_GENERIC_H

#include <effects.hpp>
#include <query.hpp>
#include <record.hpp>
#include <inference/proposal.hpp>

#include <iostream>

template<
    typename I,
    typename O,
    typename V,
    template<class, class, class...> class Q,
    typename P,
    typename... Ts
>
void 
is_step(
    pp_t<I, O, Ts...> f,
    Q<V, O, Ts...>& queryer,
    I input, 
    P& proposal,
    inf_options_t opts
) {
    auto proposed_record = proposal();
    record_t<Ts...> r = proposed_record;
    // std::cout << "proposed" << std::endl;
    // std::cout << display(r) << std::endl;
    O o = f(r, input);
    queryer.update(r, o, logprob(r) - logprob(proposed_record), opts);
    // std::cout << "replayed" << std::endl;
    // std::cout << display(r) << std::endl;
}

/**
 * @brief Importance sampling using a generic proposal distribution.
 * 
 * @tparam I The input type of the program on which to perform inference
 * @tparam O The output type of the program on which to perform inference
 * @tparam V The type emitted by the queryer
 * @tparam Q The queryer type
 * @tparam P The proposal type
 * @tparam Ts The collection of types used in the probabilistic program
 * @param f The probabilistic program to be queried
 * @param queryer The instantiated queryer class
 * @param input The input to the probabilistic program
 * @param proposal The instantiated proposal class
 * @param opts inference options
 * @return V the resutl of calling the queryer's emit method
 */
template<
    typename I,
    typename O,
    typename V,
    template<class, class, class...> class Q,
    typename P,
    typename... Ts
>
V importance_sampling(
    pp_t<I, O, Ts...>& f,
    Q<V, O, Ts...>& queryer,
    I input,
    P& proposal,
    inf_options_t opts
) {
    for (size_t n = 0; n != opts._num_iterations; n++) {
        is_step(f, queryer, input, proposal, opts);
    }
    return queryer.emit();
}

#endif  // IS_GENERIC_H