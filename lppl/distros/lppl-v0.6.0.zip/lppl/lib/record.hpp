/**  
 * @file
 * This file is part of lppl.
 * Copyright David Rushing Dewhurst, 2022 - present.
 * Released under LGPL v3
 */

#ifndef RECORD_H
#define RECORD_H

#include <cstddef>
#include <functional>
#include <memory>
#include <set>
#include <sstream>
#include <string>
#include <unordered_map>
#include <type_traits>
#include <utility>
#include <variant>

#include <functional_util.hpp>
#include <distributions.hpp>


const auto __COMPILERNG__ = [](){ return 2022ULL; };

using namespace Distributions;

/**
 * @brief Node-level interpretations.
 * 
 * + __standard__: no special interpretation
 * + __replay__: the node should be replayed through the record, pretending as
 *  though the value in the node had been sampled from the distribution, with
 *  no other changes to node structure other than updated log probability
 * + __condition__: the node should be conditioned on the value in the node (and hence
 *  the node is converted into an observed node)
 * + __block__: converts the node to untraced randomness
 * 
 */
enum interp_t {
    __standard__,
    __replay__,
    __condition__,
    __block__
};

/**
 * @brief A fundamental data structure that includes address, distribution,
 * sampled value type, score, whether the value was observed, and a markov process
 * over interpretations
 * 
 * @tparam D the type of the distribution in the node; the value type is deduced
 *  from the distribution
 */
template<typename D>
struct node_t {
    std::string address;
    D distribution;
    decltype(std::declval<D>().sample(__COMPILERNG__)) value;
    double logprob;
    bool obs;
    interp_t interp;
    interp_t last_interp;
    
    /**
     * @brief Returns a string representation of the node, not including interpretation.
     * 
     * @return std::string 
     */
    std::string string() const {
        std::string r = "";
        r += "node_t(address=" + address;
        r += ", distribution=" + distribution.string();
        r += ", value=" + stringify(value);
        r += ", logprob=" + std::to_string(logprob);
        r += obs ? ", obs=true" : ", obs=false";
        r += ")";
        return r;
    }
};

/**
 * @brief Creates a node with specified address by sampling value from corresponding
 *  distribution, then scoring it.
 * 
 */
template<typename D, typename RNG>
node_t<D> sample(std::string address, D dist, RNG& rng) {
    auto value = dist.sample(rng);
    return node_t<D> {
        address,
        dist,
        value,
        dist.logprob(value),
        false,
        __standard__,
        __standard__
    };
}

/**
 * @brief Creates a node with specified address by scoring passed value from
 *  corresponding distribution.
 * 
 */
template<typename D, typename V>
node_t<D> observe(std::string address, D dist, V value) {
    return node_t<D> {
        address,
        dist,
        value,
        dist.logprob(value),
        true,
        __condition__,
        __condition__
    };
}


template<typename... Ts>
using var_node_t = std::variant<node_t<Ts>...>;

template<typename... Ts>
using var_ret_t = std::variant<decltype(std::declval<Ts>().sample(__COMPILERNG__))...>;

template<typename... Ts>
using node_map_t = std::unordered_map<std::string, var_node_t<Ts...>>;

/**
 * @brief Record-level intepretation. Setting a record-level interpretation apart
 *  from __r_standard__ will force calls to sample/oberve to disregard any node-level
 *  interpretation.
 * 
 * + __r_standard__: no special interpretation
 * + __r_replay__: replay the record through the program
 * + __r_block_obs__: block all observed sites
 * + __r_block_sample__: block all sample sites
 * 
 */
enum record_interp_t {
    __r_standard__,
    __r_replay__,
    __r_block_obs__,
    __r_block_sample__
};

/**
 * @brief A fundamental data structure that holds an unordered_map of addresses to
 *  nodes, an insertion order, and a record-level interpretation.
 * 
 * @tparam Ts types of all nodes contained in the record. 
 */
template<typename... Ts>
struct record_t {
    node_map_t<Ts...> map;
    std::vector<std::string> addresses;
    record_interp_t interp;

    /**
     * @brief Clears the underlying map and insertion order.
     * 
     */
    void clear() {
        map.clear();
        addresses.clear();
    }
};

/**
 * @brief Samples a value into a node stored at the address by drawing a value from
 *  the specified distribution. Returns the underlying value (the .value attribute)
 *  of the created node.
 * 
 */
template<typename D, typename RNG, typename... Ts>
auto sample(record_t<Ts...>& r, std::string address, D dist, RNG& rng) {
    if (r.interp == __r_standard__) {
        return _sample_with_node_interp<D, RNG, Ts...>(r, address, dist, rng);
    } else {
        return _sample_with_record_interp<D, RNG, Ts...>(r, address, dist, rng);
    }
}

template<typename D, typename RNG, typename... Ts>
auto _sample_with_record_interp(record_t<Ts...>& r, std::string address, D dist, RNG& rng) {
    if (r.interp == __r_replay__) {
        return _replay<D, Ts...>(r, address, dist);
    } else if (r.interp == __r_block_sample__) {
        return _block_sample<D, RNG, Ts...>(r, address, dist, rng);
    // no need for __r_block_obs__ here as sampling only
    // TODO is that true? What if the site is conditioned?
    } else {
        return _sample_with_node_interp<D, RNG, Ts...>(r, address, dist, rng);
    }
}

template<typename D, typename RNG, typename... Ts>
auto _sample_with_node_interp(record_t<Ts...>& r, std::string address, D dist, RNG& rng) {
    if (!r.map.contains(address)) {
        return _standard(r, address, dist, rng);
    } else {
        using ThisT = decltype(std::declval<D>().sample(__COMPILERNG__));
        auto get = [&](auto& node) -> unique_variant_t<var_ret_t<Ts...>> {
            if (node.interp == __replay__) return _replay(r, address, dist);
            else if (node.interp == __condition__) return _condition(r, address, dist);
            else if (node.interp == __block__) return _block_sample(r, address, dist, rng);
            else return _standard(r, address, dist, rng);
        };
        return std::get<ThisT>(std::visit(get, r.map[address]));
    }
}

template<typename D, typename RNG, typename... Ts>
auto _block_sample(record_t<Ts...>& r, std::string address, D dist, RNG& rng) {
    r.map.erase(address);
    return dist.sample(rng);
}

template<typename D, typename RNG, typename... Ts>
auto _standard(record_t<Ts...>&r, std::string address, D dist, RNG& rng) {
    auto node = sample(address, dist, rng);
    if (!r.map.contains(address)) r.addresses.push_back(address);
    r.map.insert_or_assign(address, node);
    return node.value;
}

template<typename D, typename... Ts>
auto _replay(record_t<Ts...>& r, std::string address, D dist) {
    using ThisT = decltype(std::declval<D>().sample(__COMPILERNG__));
    auto value = std::get<ThisT>(
        std::visit(
            [](auto& node) -> unique_variant_t<var_ret_t<Ts...>> { return node.value; },
            r.map[address]
        )
    );
    auto last_interp = std::visit(
        [](auto& node) -> interp_t { return node.last_interp; },
        r.map[address]
    );
    auto obs = std::visit(
        [](auto& node) -> bool { return node.obs; },
        r.map[address]
    );
    auto node = node_t<D> { 
        .address=address,
        .distribution=dist,
        .value=value,
        .logprob=dist.logprob(value),
        .obs=obs,
        .interp=last_interp,
        .last_interp=__replay__
    };
    r.map.insert_or_assign(address, node);
    return node.value;
}

template<typename D, typename... Ts> 
auto _condition(record_t<Ts...>& r, std::string address, D dist) {
    using ThisT = decltype(std::declval<D>().sample(__COMPILERNG__));
    auto value = std::get<ThisT>(
        std::visit(
            [](auto& node) -> unique_variant_t<var_ret_t<Ts...>> { return node.value; },
            r.map[address]
        )
    );
    auto last_interp = std::visit(
        [](auto& node) -> interp_t { return node.last_interp; },
        r.map[address]
    );
    auto node = node_t<D> { 
        .address=address,
        .distribution=dist,
        .value=value,
        .logprob=dist.logprob(value),
        .obs=true,
        .interp=__condition__,
        .last_interp=last_interp
    };
    r.map.insert_or_assign(address, node);
    return node.value;
}

/**
 * @brief Scores the passed value against the distribution, storing the result in the
 *  record at the specified address.
 * 
 */
template<typename D, typename V, typename... Ts>
V observe(record_t<Ts...>& record, std::string address, D dist, V value) {
    if (record.interp == __r_standard__) {
        return _observe_with_node_interp<D, V, Ts...>(record, address, dist, value);
    } else {
        return _observe_with_record_interp<D, V, Ts...>(record, address, dist, value);
    }
}

template<typename D, typename V, typename... Ts>
V _observe_with_record_interp(record_t<Ts...>& record, std::string address, D dist, V value) {
    // no need for __r_replay__ since no differentiated node effect
    // no need for __r_block_sample__ since observed
    if (record.interp == __r_block_obs__) {
        return _block_observe<D, V, Ts...>(record, address, dist, value);
    } else {
        return _observe_with_node_interp<D, V, Ts...>(record, address, dist, value);
    }
}

template<typename D, typename V, typename... Ts>
V _observe_with_node_interp(record_t<Ts...>& record, std::string address, D dist, V value) {
    if (!record.map.contains(address)) {
        return _observe(record, address, dist, value);
    } else {
        using ThisT = decltype(std::declval<D>().sample(__COMPILERNG__));
        auto get = [&](auto& node) -> unique_variant_t<var_ret_t<Ts...>> {
            // observe *means* condition, and replay doesn't make sense here
            if (node.interp == __block__) return _block_observe(record, address, dist, value);
            else return _observe(record, address, dist, value);
        };
        return std::get<ThisT>(
            std::visit(get, record.map[address])
        );
    }
}

template<typename D, typename V, typename... Ts>
V _observe(record_t<Ts...>& record, std::string address, D dist, V value) {
    if (!record.map.contains(address)) record.addresses.push_back(address);
    record.map.insert_or_assign(address, observe(address, dist, value));
    return value;
}

template<typename D, typename V, typename... Ts>
V _block_observe(record_t<Ts...>& r, std::string address, D, V value) {
    r.map.erase(address);
    return value;
}

// TODO [priority:MED] reimplement as instances of generic fold

/**
 * @brief Returns a string representation of the record. Does not display
 *  node- or record-level interpretations.
 * 
 */
template <typename... Ts>
std::string display(record_t<Ts...>& record) {
    auto disp = [](auto node) -> std::string { return node.string(); };
    std::string s = "record_t(\n";
    for (const auto& address : record.addresses) {
        s += "  address=" + address + ", node=" + std::visit(disp, record.map[address]) + "\n";
    }
    s += ")";
    return s;
}

/**
 * @brief Computes the cumulative log probability of the record.
 * 
 */
template<typename... Ts>
double logprob(record_t<Ts...>& record) {
    auto get_lp = [](auto node) -> double { return node.logprob; };
    double lp = 0.0;
    for (const auto& [_, v] : record.map) {
        lp += std::visit(get_lp, v);
    }
    return lp;
}

/**
 * @brief Computes the cumulative log-likelihood of the record. The log-likelihood
 *  is defined as the sum of the log probability of all nodes with obs = true. 
 * 
 */
template<typename... Ts>
double loglikelihood(record_t<Ts...>& record) {
    auto get_ll = [](auto node) -> double { return node.obs ? node.logprob : 0.0; };
    double ll = 0.0;
    for (const auto& [_, v] : record.map) {
        ll += std::visit(get_ll, v);
    }
    return ll;
}

#endif  // RECORD_H
