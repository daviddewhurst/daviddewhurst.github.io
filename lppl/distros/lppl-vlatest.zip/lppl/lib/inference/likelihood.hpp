/** 
 * @file  
 * This file is part of lppl.
 * Copyright David Rushing Dewhurst, 2022 - present.
 * Released under LGPL v3
 */

#ifndef LW_H
#define LW_H

#include <cstddef>
#include <functional>
#include <iostream>
#include <limits>
#include <memory>
#include <sstream>
#include <string>
#include <unordered_map>
#include <utility>
#include <variant>

#include <effects.hpp>
#include <record.hpp>
#include <query.hpp>


template<typename I, typename O, typename V, template<class, class, class...> class Q, typename... Ts>
void lw_step(record_t<Ts...>& r, pp_t<I, O, Ts...> f, Q<V, O, Ts...>& queryer, I input, inf_options_t opts) {
    O o = f(r, input);
    queryer.update(r, o, loglikelihood(r), opts);
    r.clear();
}

/**
 * @brief Importance sampling using the prior distribution as the proposal
 * 
 * @tparam I The input type of the program on which to perform inference
 * @tparam O The output type of the program on which to perform inference
 * @tparam V The type emitted by the queryer
 * @tparam Q The queryer type
 * @tparam Ts The collection of types used in the probabilistic program
 * @param f The probabilistic program to be queried
 * @param queryer the instantiated queryer class
 * @param input the input to the probabilistic program
 * @param opts inference options
 * @return V the result of calling the queryer's emit method
 */
template<typename I, typename O, typename V, template<class, class, class...> class Q, typename... Ts>
V likelihood_weighting(pp_t<I, O, Ts...>& f, Q<V, O, Ts...>& queryer, I input, inf_options_t opts) {
    record_t<Ts...> r;
    for (size_t n = 0; n != opts._num_iterations; n++) {
        lw_step(r, f, queryer, input, opts);
    }
    return queryer.emit();
}


#endif  // LW_H