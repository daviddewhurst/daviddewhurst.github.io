/* 
 * This file is part of lppl.
 * Copyright David Rushing Dewhurst, 2022 - present.
 * Released under LGPL v3
 */

#include <distributions.hpp>
#include <record.hpp>
#include <inference/likelihood.hpp>
#include <query.hpp>
#include <effects.hpp>

#include <cmath>
#include <functional>
#include <iostream>
#include <memory>
#include <optional>
#include <random>
#include <string>
#include <variant>
#include <vector>

using namespace Distributions;


std::minstd_rand rng(20220902);


/**
 * @brief A linked list implementation. We could have used the std implementation, but this is
 * to prove/belabor the point that lppl programs can be used with any types you like
 * 
 * @tparam Ts the types that can be contained as data in nodes in the linked list
 */
template<typename... Ts>
class LinkedList {
    protected:
        class Node {
            public:
                std::variant<Ts...> _data;
                std::shared_ptr<Node> _next;

                Node(std::variant<Ts...> data, std::shared_ptr<Node> next)
                    : _data(data), _next(next) {}
        };

        std::shared_ptr<Node> head;
        std::shared_ptr<Node> at = head;
        int length = 0;

    public:
        void push(std::variant<Ts...> data) {
            head = std::make_shared<Node>(data, head); 
            at = head;
            length += 1;
        }
        std::variant<Ts...> get() {
            auto r = at->_data;
            at = at->_next;
            return r;
        }
        void reset() {
            at = head;
        }
        int size() {
            return length;
        }
};

struct Node {
    virtual std::string str() = 0;
};

struct A : Node {
    std::string str() override { return "A"; }
};

struct B : Node {
    std::string str() override { return "B"; };
};


void linked_list_demo() {
    LinkedList<A, B> ll; 
    ll.push(B());
    ll.push(A());
    ll.push(A());
    ll.push(B());

    auto getter = [](auto n){ return n.str(); };
    for (size_t ix = 0; ix != ll.size(); ix++) {
        std::cout << std::visit(getter, ll.get()) << std::endl;
    }
}


/**
 * @brief Counts the number of A and B instances in a linked list
 * 
 */
struct signed_accum_t{
    double a_sum;
    double b_sum;
};

struct prog_state_t {
    double a_sum;
    double b_sum;
    bool has_a;
    bool has_b;
    std::string str_ix;
    int ix;
};

void internal_ll_block(record_t<Normal, Categorical>& r, std::shared_ptr<LinkedList<A, B>> ll, prog_state_t& state) {
    state.str_ix = std::to_string(state.ix);
    auto a_or_b = sample(r, "a or b at " + state.str_ix, Categorical(), rng);
    (a_or_b > 0) ? ll->push(A()) : ll->push(B());
    if (a_or_b > 0) {
        state.a_sum += sample(r, "A value at " + state.str_ix, Normal(1.0), rng) / (state.ix + 1.0);
        state.has_a = true;
    } else {
        state.b_sum += sample(r, "B value at " + state.str_ix, Normal(-1.0), rng) / (state.ix + 1.0);
        state.has_b = true;
    }
    state.ix++;
}

/**
 * @brief Defines a generative model of linked lists and how they relate to conditional accumulation
 *
 *  1) linked lists are at least length 1
 *  2) there is at least one of each A and B in the list
 *  3) A types are more likely to generate negative numbers; B types are more likely to generate positive numbers
 *  4) Older numbers (i.e., values generated closer to the end of the list) are downweighted in the accumulation
 *  What do these linked lists look like, given observations of accumulations from As and Bs?
 * 
 * @return std::shared_ptr<LinkedList<A, B>> 
 */
std::shared_ptr<LinkedList<A, B>> ll_dist(record_t<Normal, Categorical>& r, signed_accum_t data) {
    auto ll = std::make_shared<LinkedList<A, B>>();
    int keep_going;
    prog_state_t state = { .a_sum=0.0, .b_sum=0.0, .has_a=false, .has_b=false, .str_ix="", .ix=0};
    do {
        internal_ll_block(r, ll, state);
    } while (!state.has_a || !state.has_b);
    do {
        keep_going = sample(r, "keep going after " + state.str_ix + "?", Categorical(), rng);
        internal_ll_block(r, ll, state);
    } while (keep_going > 0);

    observe(r, "a sum", Normal(state.a_sum), data.a_sum);
    observe(r, "b sum", Normal(state.b_sum), data.b_sum);
    // note this isn't memory efficient, but the point is that we actually return a distribution
    // over linked lists!
    return ll;
}


int linked_list_inference_demo() {
    auto q = weighted_record<std::shared_ptr<LinkedList<A, B>>, Normal, Categorical>();
    auto opts = inf_options_t{ ._num_iterations=5 };
    auto obs = signed_accum_t{ .a_sum=4.3, .b_sum=-2.0 };
    pp_t<signed_accum_t, std::shared_ptr<LinkedList<A, B>>, Normal, Categorical> f = ll_dist;
    auto some_records = likelihood_weighting(f, *q, obs, opts);
    std::cout << "Generated " << opts._num_iterations << " records:" << std::endl;
    for (auto& r : some_records->_v) {
        std::cout << display(r) << std::endl;
    }
    auto r_samp = some_records->sample(rng);
    std::cout << "Sampled record:\n" << display(*r_samp) << std::endl;
    return 0;
}


int main(int argc, char ** argv) {

    std::cout << "~~~ linked list demo ~~~" << std::endl;
    linked_list_demo();
    std::cout << "~~~ linked list inference demo ~~~" << std::endl;
    linked_list_inference_demo();

    return 0;
}