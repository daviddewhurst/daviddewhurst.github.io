/* 
 * This file is part of lppl.
 * Copyright David Rushing Dewhurst, 2022 - present.
 * Released under LGPL v3
 */

#include <distributions.hpp>
#include <record.hpp>
#include <inference/proposal.hpp>
#include <inference/importance/generic.hpp>
#include <plate.hpp>
#include <query.hpp>

#include <iostream>
#include <random>
#include <string>
#include <utility>
#include <vector>


using namespace Distributions;

std::minstd_rand rng(202);


std::pair<double, double>
normal_model(record_t<Normal>& r, double obs_val) {
    auto loc = sample(r, "loc", Normal(0.0, 2.0), rng);
    auto log_scale = sample(r, "log_scale", Normal(-1.0, 0.5), rng);
    observe(r, "obs", Normal(loc, std::exp(log_scale)), obs_val);
    return std::make_pair(loc, log_scale);
}

struct my_proposal : proposal<Normal> {
    std::pair<record_t<Normal>, double> generate() {
        record_t<Normal> r;
        sample(r, "loc", Normal(0.0, 10.0), rng);
        sample(r, "log_scale", Normal(-1.0, 2.0), rng);
        return std::make_pair(r, logprob(r));
    }
};

struct my_second_proposal : proposal<Normal> {
    std::pair<record_t<Normal>, double> generate() {
        record_t<Normal> r_ret;
        propose<Normal>(r_ret, "loc", Uniform(-15.0, 15.0), rng);
        propose<Normal>(r_ret, "log_scale", Uniform(-3.0, 3.0), rng);
        return std::make_pair(r_ret, logprob(r_ret));
    }
};

int test_proposal_incremental() {

    std::cout << "~~~ using normal proposal for normal model ~~~" << std::endl;
    my_proposal prop;
    auto r = prop();
    std::cout << display(r.first) << std::endl;

    double data = 8.0;

    using otype = std::pair<double, double>;

    pp_t<double, otype, Normal> f = normal_model;
    inf_options_t opts = { ._num_iterations = 1000 };

    auto record_q = weighted_record<otype, Normal>();
    auto records = importance_sampling(f, *record_q, data, prop, opts);
    auto r_samp = records->sample(rng);
    std::cout << "Sampled record:\n" << display(*r_samp) << std::endl;

    for (size_t ix = 0; ix != 3; ++ix) {
        auto param_samp = records->sample_output(rng);
        std::cout << "sampled loc = " << param_samp->first << ", log_scale = " << param_samp->second << std::endl;
    }

    auto mean_q = weighted_mean<otype, Normal>("loc");
    auto mean_loc = importance_sampling(f, *mean_q, data, prop, opts);
    std::cout << "Mean loc = " << mean_loc << std::endl;

    std::cout << "~~~ using uniform proposal for normal model ~~~" << std::endl;
    my_second_proposal prop2;
    auto r2 = prop2();
    std::cout << "r2 has logprob = " << r2.second << std::endl;

    auto record_q2 = weighted_record<otype, Normal>();
    records = importance_sampling(f, *record_q2, data, prop2, opts);
    r_samp = records->sample(rng);
    std::cout << "Sampled record:\n" << display(*r_samp) << std::endl;

    auto mean_q2 = weighted_mean<otype, Normal>("loc");
    mean_loc = importance_sampling(f, *mean_q2, data, prop2, opts);
    std::cout << "Mean loc = " << mean_loc << std::endl;

    return 0;
}


int main(int argc, char ** argv) {
    auto status = std::vector<int>({
        test_proposal_incremental()
    });
    if (*std::max_element(status.begin(), status.end()) > 0) {
        std::cout << "~~~ Test failed; read log for more. ~~~\n";
        return 1;
    } else {
        std::cout << "~~~ All tests passed. ~~~\n";
        return 0;
    }
}

