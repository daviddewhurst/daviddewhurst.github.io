cd include
git clone -b 'master' git@github.com:ryanhaining/cppitertools.git
cd ..