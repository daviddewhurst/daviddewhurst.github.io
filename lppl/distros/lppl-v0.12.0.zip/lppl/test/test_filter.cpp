/* 
 * This file is part of lppl.
 * Copyright David Rushing Dewhurst, 2022 - present.
 * Released under GPL v3
 */

#include <distributions.hpp>
#include <record.hpp>

#include <inference/filter.hpp>
#include <inference/proposal.hpp>
#include <inference/importance/likelihood.hpp>
#include <inference/importance/generic.hpp>
#include <inference/metropolis/base.hpp>

#include <query.hpp>

#include <iostream>
#include <string>
#include <utility>
#include <vector>

using namespace Distributions;

std::minstd_rand rng(202);

double normal_model(record_t<Normal, Gamma>& r, double data) {
    auto loc = sample(r, "loc", Normal(), rng);
    auto scale = sample(r, "scale", Gamma(0.25, 5.0), rng);
    observe(r, "obs", Normal(loc, scale), data);
    return loc;
}

struct normal_trans_kernel : transition<double, Normal, Gamma> {

    double loc;

    void update(FilterValueType<double, Normal, Gamma>& cache) {
        std::cout << "normal_trans_kernel: loc estimate before update = " << loc << std::endl;
        size_t ix = 0;
        loc = 0.0;
        for (auto& r : cache->_v) {
            loc += std::visit([&cache, &ix](auto& n){ return n.value * cache->prob_at(ix); }, r.map["loc"]);
            ++ix;
        }
        loc = 0.1 * loc + 0.9 * std::visit([](auto& n){ return n.value; }, cache->_v[0].map["obs"]);
    }

    std::pair<record_t<Normal, Gamma>, double> generate() {
        record_t<Normal, Gamma> r;
        sample(r, "loc", Normal(loc, 1.0), rng);
        sample(r, "scale", Gamma(0.5, 0.5), rng);
        return std::make_pair(r, logprob(r));
    }

};

struct normal_proposal : proposal<Normal, Gamma> {

    // use the past transition dynamics to inform our proposal! :)
    normal_trans_kernel& trans;

    normal_proposal(normal_trans_kernel& trans) : trans(trans) {}

    std::pair<record_t<Normal, Gamma>, double> generate() {
        record_t<Normal, Gamma> r;
        sample(r, "loc", Normal(trans.loc, 2.0), rng);
        sample(r, "scale", Gamma(2.0, 2.0), rng);
        return std::make_pair(r, logprob(r));
    }
};

int test_filter_basic() {

    double data = 3.0;
    size_t iters = 5;
    pp_t<double, double, Normal, Gamma> f = normal_model;
    auto opts = inf_options_t(100);

    auto get_value = [](auto& n) -> double { return n.value; };
    auto q = weighted_record<double, Normal, Gamma>();
    normal_trans_kernel trans;
    trans.loc = 0;
    auto infer = filter<LikelihoodWeighting>(f, *q, trans, opts);
    auto mean_ = [](std::vector<double>& v) {return std::accumulate(v.begin(), v.end(), 0.0) / v.size(); };

    // filter 1!
    std::cout << "~~~ using default particle filtering ~~~" << std::endl;
    for (size_t ix = 0; ix != iters; ix++) {
        std::cout << "\niteration " << ix << ", data = " << data << std::endl;
        auto value = infer.step(data);
        auto locs = value->template at<double>("loc").sample(rng, 100);
        std::cout << "mean posterior loc = " << mean_(*locs) << std::endl;
        auto scales = value->template at<double>("scale").sample(rng, 100);
        std::cout << "mean posterior scale = " << mean_(*scales) << std::endl;

        // random update
        auto sampled = value->sample_output(rng);
        data += Normal().sample(rng);
    }

    // inference machinery -- this time with a separate proposal distribution...
    trans.loc = 0;
    auto prop = normal_proposal(trans);
    q->clear();
    auto infer2 = filter<ImportanceSampling>(f, *q, trans, opts);

    // filter 2!
    std::cout << "\n\n~~~ using particle filtering with custom proposal ~~~" << std::endl;
    for (size_t ix = 0; ix != iters; ix++) {
        std::cout << "\niteration " << ix << ", data = " << data << std::endl;
        // note that we could pass a *different* proposal at each timestep if we chose!
        auto value = infer2.step(data, prop);
        auto locs = value->template at<double>("loc").sample(rng, 100);
        std::cout << "mean posterior loc = " << mean_(*locs) << std::endl;
        auto scales = value->template at<double>("scale").sample(rng, 100);
        std::cout << "mean posterior scale = " << mean_(*scales) << std::endl;

        // random update
        auto sampled = value->sample_output(rng);
        data += Normal().sample(rng);
    }

    // inference machinery -- this time with metropolis approximate posterior
    trans.loc = 0;
    q->clear();
    size_t thin = 100;
    size_t burn = 1000;
    size_t num_pts = 100;
    auto opts2 = inf_options_t(thin, burn, burn + num_pts * thin);
    auto infer3 = filter<AncestorMetropolis>(f, *q, trans, opts2);

    // filter 3!
    std::cout << "\n\n~~~ using metropolis hastings particle filtering ~~~" << std::endl;
    for (size_t ix = 0; ix != iters; ix++) {
        std::cout << "\niteration " << ix << ", data = " << data << std::endl;
        // note that we could pass a *different* proposal at each timestep if we chose!
        auto value = infer3.step(data);
        auto locs = value->template at<double>("loc").sample(rng, 100);
        std::cout << "mean posterior loc = " << mean_(*locs) << std::endl;
        auto scales = value->template at<double>("scale").sample(rng, 100);
        std::cout << "mean posterior scale = " << mean_(*scales) << std::endl;
        // alternative way of computing these queries, saving memory
        std::cout << "[alt computation] mean posterior loc = " << mean(value, "loc") << std::endl;
        std::cout << "[alt computation] mean posterior scale = " << mean(value, "scale") << std::endl;
        std::cout << "posterior score = " << score(value) << std::endl;

        // random update
        auto sampled = value->sample_output(rng);
        data += Normal().sample(rng);
    }
    
    return 0;
}

int main(int argc, char ** argv) {
    auto status = std::vector<int>({
        test_filter_basic()
    });
    if (*std::max_element(status.begin(), status.end()) > 0) {
        std::cout << "~~~ Test failed; read log for more. ~~~\n";
        return 1;
    } else {
        std::cout << "~~~ All tests passed. ~~~\n";
        return 0;
    }
}
