/** 
 * @file 
 * This file is part of lppl.
 * Copyright David Rushing Dewhurst, 2022 - present.
 * Released under LGPL v3
 */

#ifndef PLATE_H
#define PLATE_H

#include <array>
#include <string>
#include <type_traits>

#include <distributions.hpp>

template<typename D>
struct plate {
    using DistValueType = decltype(std::declval<D>().sample(__COMPILERNG__));
    D dist;

    template<typename... Ts>
    plate(Ts... ts) {
        dist = D(ts...);
    }
};

/**
 * @brief Defines a generic plated distribution.
 * 
 * Suppose that \f$ z \sim p(z|D) \f$. Then this struct defines the distribution
 * \f$ z_1,...,z_N \sim \prod_{1\leq n \leq N} p(z_n|D)\f$.
 * 
 * @tparam D the underlying distribution type
 * @tparam N the compile-time constant dimensionality of the plate
 */
template<typename D, size_t N>
struct static_plate : plate<D> {

    /**
     * @brief Construct a new static plate.
     * 
     * Forwards all passed arguments to D constructor.
     * 
     * @tparam Ts
     * @param ts arguments to pass to underlying distribution
     */
    template<typename... Ts>
    static_plate(Ts... ts) : plate<D>(ts...) {}

    template<typename RNG>
    std::array<typename plate<D>::DistValueType, N> sample(RNG& rng) {
        std::array<typename plate<D>::DistValueType, N> out;
        for (size_t ix = 0; ix != N; ix++) {
            out[ix] = this->dist.sample(rng);
        }
        return out;
    }

    double logprob(std::array<typename plate<D>::DistValueType, N> value) {
        double out = 0.0;
        for (size_t ix = 0; ix != N; ix++) out += this->dist.logprob(value[ix]);
        return out;
    }

    std::string string() const {
        return "static_plate<" + this->dist.string() + ", " + std::to_string(N) + ">";
    }

};

/**
 * @brief Defines a generic shared pointer plated distribution.
 * 
 *  * Suppose that \f$ z \sim p(z|D) \f$. Then this struct defines the distribution
 * \f$ z_1,...,z_N \sim \prod_{1\leq n \leq N} p(z_n|D)\f$.
 * 
 * @tparam D the underlying distribution type
 * @tparam N the compile-time constant dimensionality of the plate
 */
template<typename D, size_t N>
struct shared_static_plate : plate<D> {

    /**
     * @brief Construct a new shared pointer static plate.
     * 
     * Forwards all passed arguments to D constructor.
     * 
     * @tparam Ts
     * @param ts arguments to pass to underlying distribution
     */
    template<typename... Ts>
    shared_static_plate(Ts... ts) : plate<D>(ts...) {}

    template<typename RNG>
    std::shared_ptr<std::array<typename plate<D>::DistValueType, N>>
    sample(RNG& rng) {
        auto out = std::make_shared<std::array<typename plate<D>::DistValueType, N>>();
        for (size_t ix = 0; ix != N; ix++) {
            out->operator[](ix) = this->dist.sample(rng);
        }
        return out;
    }

    double logprob(std::shared_ptr<std::array<typename plate<D>::DistValueType, N>> value) {
        double out = 0.0;
        for (size_t ix = 0; ix != N; ix++) out += this->dist.logprob(value->operator[](ix));
        return out;
    }

    double logprob(std::array<typename plate<D>::DistValueType, N> * value) {
        auto v = *value;
        double out = 0.0;
        for (size_t ix = 0; ix != N; ix++) out += this->dist.logprob(v[ix]);
        return out;
    }

    std::string string() const {
        return "shared_static_plate<" + this->dist.string() + ", " + std::to_string(N) + ">";
    }

};

#endif  // PLATE_H