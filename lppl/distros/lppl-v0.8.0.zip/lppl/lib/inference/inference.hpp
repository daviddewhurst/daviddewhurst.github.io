/** 
 * \file inference.hpp
 * This file is part of lppl.
 * Copyright David Rushing Dewhurst, 2022 - present.
 * Released under LGPL v3
 */

#ifndef INFERENCE_H
#define INFERENCE_H

#include <type_traits>

#include <effects.hpp>
#include <record.hpp>
#include <query.hpp>

/**
 * @brief Will the passed class template have an associated proposal distribution?
 * 
 * @tparam C The class template to check
 */
template<template<class, class, class, template<class, class, class...> class, typename...> class C>
struct has_proposal {
    static constexpr bool value = false;
};

template<
    typename I,
    typename O,
    typename V,
    template<class, class, class...> class Q,
    typename... Ts
>
struct InferenceBase {
    pp_t<I, O, Ts...>& f;
    Q<V, O, Ts...>& queryer;
    inf_options_t opts; 

    InferenceBase(
        pp_t<I, O, Ts...>& f,
        Q<V, O, Ts...>& queryer,
        inf_options_t opts
    ) : f(f), queryer(queryer), opts(opts) {}
};

/**
 * @brief Universal base class for inference methods. 
 * 
 * @tparam A The class template of the inference method
 * @tparam I The type of the input data
 * @tparam O The type of the output data
 * @tparam V The type of the query variable(s)
 * @tparam Q The class template of the queryer
 * @tparam HasProposal will the passed class template have an associated proposal
 *  class?
 * @tparam Ts The distribution types in the program
 */
template<
    template<
        typename,
        typename,
        typename,
        template<class, class, class...> class,
        typename...
    > class A,
    typename I,
    typename O,
    typename V,
    template<class, class, class...> class Q,
    bool HasProposal = has_proposal<A>::value,
    typename... Ts
>
struct Inference 
    : InferenceBase<I, O, V, Q, Ts...> {

    Inference(
        pp_t<I, O, Ts...>& f,
        Q<V, O, Ts...>& queryer,
        inf_options_t opts
    ) : InferenceBase<I, O, V, Q, Ts...>(f, queryer, opts) {}

    template<class P>
    V operator()(I& input, P& proposal) {
        return static_cast<A<I, O, V, Q, Ts...>*>(this)->template operator()(input, proposal);
    }

};

template<
    template<
        typename,
        typename,
        typename,
        template<class, class, class...> class,
        typename...
    > class A,
    typename I,
    typename O,
    typename V,
    template<class, class, class...> class Q,
    typename... Ts
>
struct Inference<A, I, O, V, Q, false, Ts...> 
    : InferenceBase<I, O, V, Q, Ts...> {

    Inference(
        pp_t<I, O, Ts...>& f,
        Q<V, O, Ts...>& queryer,
        inf_options_t opts
    ) : InferenceBase<I, O, V, Q, Ts...>(f, queryer, opts) {}

    V operator()(I& input) {
        return static_cast<A<I, O, V, Q, Ts...>*>(this)->operator()(input);
    }

};

/**
 * @brief Factory function for Inference instances
 * 
 */
template<
    template<
        typename,
        typename,
        typename,
        template<class, class, class...> class Q,
        typename...
    > class A,
    typename I,
    typename O,
    typename V,
    template<class, class, class...> class Q,
    typename... Ts
>
Inference<A, I, O, V, Q, has_proposal<A>::value, Ts...>
inference(pp_t<I, O, Ts...>& f, Q<V, O, Ts...>& queryer, inf_options_t opts) {
    return Inference<A, I, O, V, Q, has_proposal<A>::value, Ts...>(f, queryer, opts);
}

#endif  // INFERENCE_H
